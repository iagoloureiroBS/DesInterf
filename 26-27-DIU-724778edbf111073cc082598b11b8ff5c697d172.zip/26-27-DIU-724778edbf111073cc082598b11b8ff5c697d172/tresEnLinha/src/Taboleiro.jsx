import { useState } from "react";

function Cadrado({valor, onCadradoClic}) {
  return (
    <button 
        className="square" 
        onClick={onCadradoClic}>
            { valor }
    </button>
  );
}

export default function Taboleiro({xTurno, cadrados, onXogar}) {
  let estado;
  const ganador = calcularGanador(cadrados);    

  if (ganador){
    estado = "Ganador: " + ganador;
  } else {
    estado = "Seguinte xogador: " + (xTurno? "X" : "O");
  }

  function  handleClick(i) {
    if (calcularGanador(cadrados) || cadrados[i]) {
      return;
    }
    const novosCadrados = cadrados.slice();    

    if (xTurno) {
        novosCadrados[i] = "X";
    }else {
        novosCadrados[i] = "O";
    }
    
    onXogar(novosCadrados);
    
  }

  return (
        <>
      <div>{estado}</div>
      <div className="board-row">
        <Cadrado valor={cadrados[0]} onCadradoClic={() => handleClick(0)}/>
        <Cadrado valor={cadrados[1]} onCadradoClic={() => handleClick(1)}/>
        <Cadrado valor={cadrados[2]} onCadradoClic={() => handleClick(2)}/>
      </div>
      <div className="board-row">
        <Cadrado valor={cadrados[3]} onCadradoClic={() => handleClick(3)}/>
        <Cadrado valor={cadrados[4]} onCadradoClic={() => handleClick(4)}/>
        <Cadrado valor={cadrados[5]} onCadradoClic={() => handleClick(5)}/>
      </div>
      <div className="board-row">
        <Cadrado valor={cadrados[6]} onCadradoClic={() => handleClick(6)}/>
        <Cadrado valor={cadrados[7]} onCadradoClic={() => handleClick(7)}/>
        <Cadrado valor={cadrados[8]} onCadradoClic={() => handleClick(8)}/>
      </div>
    </>
  );
}

function calcularGanador(cadrados) {
  const ganadoras = [
    [0,1,2],
    [3,4,5],
    [6,7,8],
    [0,3,6],
    [1,4,7],
    [2,5,8],
    [0,4,8],
    [2,4,6],
  ] ;

  let ganador = null;

  for (let i = 0; i < ganadoras.length; i++){
    
    let [a,b,c] = ganadoras[i];
    
    if (cadrados[a] && cadrados[a] === cadrados[b] && cadrados[a] === cadrados[c]){
      ganador = cadrados[a];
    }
    
  }

  return ganador; 

}


