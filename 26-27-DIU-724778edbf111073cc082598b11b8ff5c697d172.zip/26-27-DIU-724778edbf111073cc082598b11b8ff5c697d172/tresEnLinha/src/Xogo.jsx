import { useState } from "react";
import Taboleiro from "./Taboleiro.jsx";


export default function Xogo(){
    const [xTurno, setXTurno] = useState(true);
    const [historial, setHistorial] = useState([Array(9).fill(null)]);
    const cadradosActuais = historial[historial.length - 1];

    function handleXogo(novosCadrados) {
        // TODO
        setHistorial([...historial,novosCadrados]);
        setXTurno(!xTurno);
        console.log(historial);
    }

    const movementos = historial.map((cadados,index) => {
        return (
            <li>
                <button >{index == 0 && "Ir al inicio del juego"}{index != 0 && "Ir al movimiento "+index}</button>
            </li>
        );
    });


  return (
    <div className="game">
        <div className="game-board">
            <Taboleiro  xTurno={xTurno} cadrados={cadradosActuais} onXogar={handleXogo}/> 
        </div>
        <div className="game-info">
            
            <ol>
                {movementos}
            </ol>
        </div>
    </div>
  )
}