//################################################################################
// Las 5 pistas centrales de ReservaYa tienen iluminación inteligente cuyo consumo
// eléctrico escala de forma cuadrática según la potencia de la pista (del 1 al 5).
// Realiza un programa que calcule la suma de los consumos de las 5 pistas (1² + 2² + 3² + 4² + 5²).
//################################################################################
// Escribe tu código aquí
let sum = 0

for (let i = 1; i < 6; i++) {
    
    sum += Math.pow(i, 2)
    
}

console.log(`Resultado: ${sum}`)